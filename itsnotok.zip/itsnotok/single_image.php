<?php
nw18_add_form_page_handler_itsnotok_image_segment();

function nw18_add_form_page_handler_itsnotok_image_segment() {
    global $wpdb;
	$message = '';
    $notice = '';
    $default = array(
			'ID' => 0,
			'image' => '',			
			'display_order'=>'',
			'status' => '',
			'updated_at' => time(),
			'created_at' => time(),
			'created_by' => get_current_user_id(),
			'updated_by' => get_current_user_id(),
    );
	
    if (isset($_REQUEST['nonce']) && wp_verify_nonce($_REQUEST['nonce'], basename(__FILE__))) {
		$_REQUEST = Itsnotok_manage::nw_remove_backslashes($_REQUEST);
		$item = shortcode_atts($default, $_REQUEST);
		$item = Itsnotok_manage::nw_remove_backslashes($item);
		$item_valid = Itsnotok_manage::nw_validate_form_data($item);
		//Check validation
		if ($item_valid === true) {	
			// if id is blank call insert functon
            if ($item['ID'] == '') {				
               $new_record_id = Itsnotok_manage::nw_insert_image_segment($item);
                $item['ID'] = $new_record_id;
				 
                if ($item['ID']) {
                    $message = __('Item was successfully saved', 'pr');
                } else {
                    $notice = __('There was an error while saving item', 'pr');
                }
            }else{	
				// if id is notblank call update functon			
				$result = Itsnotok_manage::nw_update_utility_image_segment($item['ID'], $item);   
			   
			   if ($result) {
                    $message = __('Item was successfully updated', 'pr');
                } else {
                    $notice = __('There was an error while updating item', 'pr');
                } 
            }
           
        } else {
            $notice = $item_valid;
        }
      $item = Itsnotok_manage::nw_get_single_image_segment($item['ID']);
	  
	 
    } else {
       // $item = $default;
       if (isset($_REQUEST['id'])) {
            $id = $_REQUEST['id'];
           $item = Itsnotok_manage::nw_get_single_image_segment($id);
            if (!$item) {
                $item = $default;
                $notice = __('Item not found', 'pr');
            }
        }
    }

	 
     
	
	

    add_meta_box('form_meta_box', __('Image Segment Panel', 'pr'), 'nw18_itsnotok_image_segment_Panel', 'formbox', 'normal', 'default');
	
	 	//echo "<pre>";
	//print_r($item);
    ?>
 <div class="wrap">
        <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>

<h2><?php _e('From The Fact Files Panel', 'pr') ?>
        <a class="add-new-h2" href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=' . Itsnotok_manage::$page_slug4); ?>"><?php _e('All Listing', 'pr') ?></a>    
        <a class="add-new-h2" href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=' . Itsnotok_manage::$page_slug4 . '&action=new'); ?>"><?php _e('Add New', 'pr') ?></a>    
    </h2>
    


    <?php if (!empty($notice)): ?>
        <div id="notice" class="error"><p><?php echo $notice ?></p></div>
    <?php endif; ?>
    <?php if (!empty($message)): ?>
        <div id="message" class="updated"><p><?php echo $message ?></p></div>
    <?php endif; ?>

    <form id="form" name="frmdata" method="post" enctype="multipart/form-data" class="nw">
        <input type="hidden" name="nonce" value="<?php echo wp_create_nonce(basename(__FILE__)) ?>"/>
        <input type="hidden" name="ID" value="<?php echo (!empty($item['ID'])) ? $item['ID'] : ''; ?>"/>        
        <input type="hidden" name="created_at" value="<?php echo (!empty($item['created_at'])) ? $item['created_at'] : ''; ?>"/>
        <input type="hidden" name="created_by" value="<?php echo (!empty($item['created_by'])) ? $item['created_by'] : ''; ?>"/>
        <input type="hidden" name="updated_by" value="<?php echo (!empty($item['updated_by'])) ? $item['updated_by'] : ''; ?>"/>
      
        <div class="metabox-holder" id="poststuff">
            <div id="post-body">
                <div id="post-body-content">

                    <?php do_meta_boxes('formbox', 'normal', $item); ?>
                    <input type="submit" value="<?php _e('Save', 'pr') ?>" id="submit" class="button-primary" name="submit">
                </div>
            </div>
        </div>
    </form>
	
	
	
	
	  <div style="clear:both"></div>
    <?php

}


function nw18_itsnotok_image_segment_Panel($item) {

?>

<style>
    div.postbox {width: 100%; margin-left: 10px;float: left;}
label{font-weight:bold;}
.inside {
    float: left;
    width: 100%;
}
	</style>
 
			
	<div class="form-row borderp">
		
<div class="form-group col-md-6">
				<label>Image upload (Only JPG,PNG,GIF Allowed)</label>
				<input type="file" id="sortpicture" name="upload" class="form-control"   accept="jpg,jped,png" />
				<?php
					if(!empty($item['image'])){
						$imageid = wp_get_attachment_image_src($item['image'],'thumbnail');
						$imageUrl = $imageid[0].'?implicy=website&width=0&height=0';
						echo '<img src='.$imageUrl.' width="50px">';
					}
				?>
             </div>


		 <div class="form-group col-md-4" style= "display:none;">
			<label for="display_order"><?php _e('Display Order:', 'pr') ?></label>
			<input id="display_order" name="display_order" type="number" class="form-control" value="<?php echo stripslashes($item['display_order']) ?>" placeholder="Enter Display Order">
		</div>
 
		<div class="clear"></div>
		<div class="form-group  col-md-12" style="display:inline-block;">
		   <label for="status">Status : </label>
			<div class="radio-inline">
				<label><input type="radio" value="1" name="status" checked <?php if ($item['status'] == '1') echo 'checked'; ?> >Active</label>
			</div>
				<div class="radio-inline">
					<label><input type="radio" value="0" name="status" <?php if ($item['status'] == '0') echo 'checked'; ?>>Inactive</label>
				</div>
		</div>

 </div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">


    <?php
}
?>

