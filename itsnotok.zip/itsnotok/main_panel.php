<?php
/*
Plugin Name: It's not ok
Description: Manage It's not ok
version: 2.0
Author: Gourav singh
*/
define('ITSNOTOK_FOLDER_ADMIN', __DIR__); 

class Itsnotok_manage {
static $page_slug = 'nw_itsnotok';
static $page_slug2 = 'nw_itsnotok_video_segment';
static $page_slug3 = 'nw_feature_video';
static $page_slug4 = 'nw_image';
static $page_slug5 = 'nw_fah';
static $page_slug6 = 'nw_did_you_know';
static $page_slug7 = 'nw_ca';
	public static function init_microsite() {
		add_action('admin_menu', array(__CLASS__, 'add_plugin'));		
	}
	
	public static function create_tables() {
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		global $wpdb;
        $collate = '';
        if ($wpdb->has_cap('collation')) {
			$collate = $wpdb->get_charset_collate();
		}
		$table_name = $wpdb->prefix . 'nw_itsnotok_tails';
         $createPushSQL = "CREATE TABLE $table_name(
		ID bigint(20) unsigned NOT NULL auto_increment,
		title varchar(255) NOT NULL,  
        description longtext NOT NULL,       
		status tinyint(10) NOT NULL default 0,
        display_order tinyint(10) NOT NULL default 0,
		updated_at varchar(50) NOT NULL,
		created_at varchar(50) NOT NULL,
		updated_by varchar(10) NOT NULL,
		created_by varchar(10) NOT NULL,
		PRIMARY KEY  (ID),
		KEY ID (ID)
		) $collate;";
        dbDelta($createPushSQL);
		
		$table_name = $wpdb->prefix . 'nw_itsnotok_video_segment';
        $createPushSQL = "CREATE TABLE $table_name(
		ID bigint(20) unsigned NOT NULL auto_increment,
		title varchar(255) NOT NULL,  
		videoId varchar(50) NOT NULL,  
        description longtext NOT NULL,       
		status tinyint(10) NOT NULL default 0,
        display_order tinyint(10) NOT NULL default 0,
		updated_at varchar(50) NOT NULL,
		created_at varchar(50) NOT NULL,
		updated_by varchar(10) NOT NULL,
		created_by varchar(10) NOT NULL,
		PRIMARY KEY  (ID),
		KEY ID (ID)
		) $collate;";
        dbDelta($createPushSQL);
		
		$table_name = $wpdb->prefix . 'nw_image_segment';
        $createPushSQL = "CREATE TABLE $table_name(
		ID bigint(20) unsigned NOT NULL auto_increment,
        image varchar(255) NOT NULL,
		status tinyint(10) NOT NULL default 0,
        display_order tinyint(10) NOT NULL default 0,
		updated_at varchar(50) NOT NULL,
		created_at varchar(50) NOT NULL,
		updated_by varchar(10) NOT NULL,
		created_by varchar(10) NOT NULL,
		PRIMARY KEY  (ID),
		KEY ID (ID)
		) $collate;";
        dbDelta($createPushSQL);
		
		$table_name = $wpdb->prefix . 'nw_did_you_know';
        $createPushSQL = "CREATE TABLE $table_name(
		ID bigint(20) unsigned NOT NULL auto_increment,
        image varchar(255) NOT NULL,
		status tinyint(10) NOT NULL default 0,
        display_order tinyint(10) NOT NULL default 0,
		updated_at varchar(50) NOT NULL,
		created_at varchar(50) NOT NULL,
		updated_by varchar(10) NOT NULL,
		created_by varchar(10) NOT NULL,
		PRIMARY KEY  (ID),
		KEY ID (ID)
		) $collate;";
        dbDelta($createPushSQL);
		
		$table_name = $wpdb->prefix . 'nw_fah';
        $createPushSQL = "CREATE TABLE $table_name(
		ID bigint(20) unsigned NOT NULL auto_increment,
		title varchar(255) NOT NULL,  
		image varchar(255) NOT NULL,   
        description longtext NOT NULL, 
        display_order tinyint(10) NOT NULL default 0,		
		status tinyint(10) NOT NULL default 0,
        updated_at varchar(50) NOT NULL,
		created_at varchar(50) NOT NULL,
		created_by varchar(10) NOT NULL,
		updated_by varchar(10) NOT NULL,
		PRIMARY KEY  (ID),
		KEY ID (ID)
		) $collate;";
        dbDelta($createPushSQL);
		
			$table_name = $wpdb->prefix . 'nw_ca';
        $createPushSQL = "CREATE TABLE $table_name(
		ID bigint(20) unsigned NOT NULL auto_increment,
		image varchar(255) NOT NULL,   
        description longtext NOT NULL, 
        display_order tinyint(10) NOT NULL default 0,		
		status tinyint(10) NOT NULL default 0,
        updated_at varchar(50) NOT NULL,
		created_at varchar(50) NOT NULL,
		created_by varchar(10) NOT NULL,
		updated_by varchar(10) NOT NULL,
		PRIMARY KEY  (ID),
		KEY ID (ID)
		) $collate;";
        dbDelta($createPushSQL);
		
		
    }


	public static function add_plugin() {
		add_menu_page('Itsnotok', 'Itsnotok', 'edit_posts', self::$page_slug, array(__CLASS__, ''),'dashicons-admin-plugins');
		add_submenu_page(self::$page_slug, 'Itsnotok Tails', 'Itsnotok Tails ', 'edit_posts', self::$page_slug, array(__CLASS__, 'nw_itsnotok_data_tails'));
		add_submenu_page(self::$page_slug, 'Video Segment', 'Video Segment ', 'edit_posts', self::$page_slug2, array(__CLASS__, 'nw_itsnotok_data_video_segment'));
		add_submenu_page(self::$page_slug, 'Feature Video', 'Feature Video ', 'edit_posts', self::$page_slug3, array(__CLASS__, 'nw_feature_video'));
		add_submenu_page(self::$page_slug, 'Image Upload', 'Image Upload ', 'edit_posts', self::$page_slug4, array(__CLASS__, 'nw_image'));
		add_submenu_page(self::$page_slug, 'FAH', 'FAH ', 'edit_posts', self::$page_slug5, array(__CLASS__, 'nw_fah'));
		add_submenu_page(self::$page_slug, 'DYK', 'DYK ', 'edit_posts', self::$page_slug6, array(__CLASS__, 'nw_did_you_know'));
		add_submenu_page(self::$page_slug, 'Campaign Ambassador ', 'Campaign Ambassador ', 'edit_posts', self::$page_slug7, array(__CLASS__, 'nw_ca'));
	}


public  function nw_ca() {
		if (!empty($_GET['action'])) {
			include_once ITSNOTOK_FOLDER_ADMIN . '/single_ca.php';
		}else{	 
			include_once ITSNOTOK_FOLDER_ADMIN . '/listing_ca.php';
		}
	}


public  function nw_did_you_know() {
		if (!empty($_GET['action'])) {
			include_once ITSNOTOK_FOLDER_ADMIN . '/single_did_you_know.php';
		}else{	 
			include_once ITSNOTOK_FOLDER_ADMIN . '/listing_did_you_know.php';
		}
	}


public  function nw_fah() {
		if (!empty($_GET['action'])) {
			include_once ITSNOTOK_FOLDER_ADMIN . '/single_fah.php';
		}else{	 
			include_once ITSNOTOK_FOLDER_ADMIN . '/listing_fah.php';
		}
	}


public  function nw_image() {
		if (!empty($_GET['action'])) {
			include_once ITSNOTOK_FOLDER_ADMIN . '/single_image.php';
		}else{	 
			include_once ITSNOTOK_FOLDER_ADMIN . '/listing_image.php';
		}
	}

	public  function nw_itsnotok_data_tails() {
		if (!empty($_GET['action'])) {
			include_once ITSNOTOK_FOLDER_ADMIN . '/single.php';
		}else{	 
			include_once ITSNOTOK_FOLDER_ADMIN . '/listing.php';
		}
	}
	
	public  function nw_itsnotok_data_video_segment() {
		if (!empty($_GET['action'])) {
			include_once ITSNOTOK_FOLDER_ADMIN . '/single_video_segment.php';
		}else{	 
			include_once ITSNOTOK_FOLDER_ADMIN . '/listing_video_segment.php';
		}
	}

    public static function nw_remove_backslashes($item) {
        foreach ($item as $item_index => $item_value) {
            $new_value = stripslashes($item_value);
            $item[$item_index] = $new_value;
        }
        return $item;
    }
	


    public static function nw_validate_form_data($item) {
        $messages = array();
        if (empty($messages))
            return true;
        return implode('<br />', $messages);
    }
	
    public static function nw_get_all_status_panel() {
        return array(
            '0' => 'Inactive',
            '1' => 'Active',
        );
    }

/* tails */
  	
	 public static function nw_insert_tails($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'nw_itsnotok_tails';
        $user_id = get_current_user_id();
        $data['created_at'] = time();
        $data['updated_by'] = $user_id;
        $data['created_by'] = $user_id;
        
        if (!empty($data['status'])) {
            $data['status'] = 1;
        }

        $wpdb->insert($table_name, $data);
        $insert_id = $wpdb->insert_id;
		//self::get_redis_zebpay();
        return $insert_id;
    }
	
	
	public static function nw_update_utility_tails($id, $data) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_itsnotok_tails';			 
		if (!empty($data['status'])) {
			$data['status'] = 1;
		}
		$result = $wpdb->update($table_name, $data, array('ID' => $id));
		//self::get_redis_zebpay();
		return $result;
    }
	
	 public static function nw_get_single_tails($id) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_itsnotok_tails';

		$data = array();
		$query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $id);

		$db_data = $wpdb->get_results($query, ARRAY_A);
		$data = array();
		if (is_array($db_data) && count($db_data) > 0) {
			$data = $db_data[0];
			//$data['data'] = unserialize($data['data']);
		}
		return $data;
      
     }
	
	 public static function get_redis_zebpay() {
			global $wpdb;
			$table_name = $wpdb->prefix . 'nw_itsnotok_tails';
			$redis_key = REDIS_KEY_PREFIX . 'nw_zebpay_data';
			$query = "SELECT bifurcation,image,videoId,description FROM `$table_name` where status = 1 ORDER BY display_order ASC, ID DESC";
			$all_events = $wpdb->get_results($query, ARRAY_A);
			print_r($all_events);
			if($all_events){
				$imgUrl = '';
				foreach($all_events as $all_event){			
					$imageid = wp_get_attachment_image_src($all_event['image'],'full');
					if($imageid[0]){
						$imageStaticPath = str_replace(home_url().'/wp-content/uploads/',STATIC_IMG_PATH,$imageid[0]);
						$imgUrl = $imageStaticPath; 
					}
					$dataArr[] = array(
						'bifurcation' => $all_event['bifurcation'],
						//'title' => $all_event['title'],								
						'videoId' => $all_event['videoId'],								
						'description' => stripslashes($all_event['description']),								
						'image' => $imgUrl,				
					);
				}
			}else{
				$dataArr[] = array();
				RedisMaster::saveJSON($redis_key, json_encode($dataArr));	
			}
			if($dataArr){
				RedisMaster::saveJSON($redis_key, json_encode($dataArr));	
			}
	 }
  
  public static function nw_update_utility_order_status($id, $data2) {
	global $wpdb;
	$table_name = $wpdb->prefix . 'nw_itsnotok_tails';
	if (!empty($data['status'])) {
		$data['status'] = 1;
	}
	$result = $wpdb->update($table_name, $data2, array('ID' => $id));
	//self::get_redis_zebpay();
	return $result;
}
  /*end Tails  */
 
 ////////////////////////*Video Segment *//////////////////
  	 public static function nw_insert_video_segment($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'nw_itsnotok_video_segment';
        $user_id = get_current_user_id();
        $data['created_at'] = time();
        $data['updated_by'] = $user_id;
        $data['created_by'] = $user_id;
        
        if (!empty($data['status'])) {
            $data['status'] = 1;
        }

        $wpdb->insert($table_name, $data);
        $insert_id = $wpdb->insert_id;
		//self::get_redis_zebpay();
        return $insert_id;
    }
	
	
	public static function nw_update_utility_video_segment($id, $data) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_itsnotok_video_segment';			 
		if (!empty($data['status'])) {
			$data['status'] = 1;
		}
		$result = $wpdb->update($table_name, $data, array('ID' => $id));
		//self::get_redis_zebpay();
		return $result;
    }
	
	 public static function nw_get_single_video_segment($id) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_itsnotok_video_segment';

		$data = array();
		$query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $id);

		$db_data = $wpdb->get_results($query, ARRAY_A);
		$data = array();
		if (is_array($db_data) && count($db_data) > 0) {
			$data = $db_data[0];
			//$data['data'] = unserialize($data['data']);
		}
		return $data;
      
     }
  
  
  ////////////////* End Video Segment *///////////////
  
  
  /////////////////////*Image Segment *///////////////
  	 public static function nw_insert_image_segment($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'nw_image_segment';
		 if($_FILES['upload']['name']) {
              if(!$_FILES['upload']['error']) {          
                $new_file_name = strtolower($_FILES['upload']['tmp_name']);        
                if($_FILES['upload']['size'] > (900000)) {                 
                  wp_die('Your file size is to large.');
                }
                else {                  
                  require_once( ABSPATH . 'wp-admin/includes/image.php' );
                  require_once( ABSPATH . 'wp-admin/includes/file.php' );
                  require_once( ABSPATH . 'wp-admin/includes/media.php' );   
                  $file_id = media_handle_upload( 'upload', 0 );				
				 if($file_id){
                  $data['image'] = $file_id;
                 }
                }
              }
              else {
                //set that to be the returned message
                wp_die('Error: '.$_FILES['upload']['error']);
              }
            } 
		
        $user_id = get_current_user_id();
        $data['created_at'] = time();
        $data['updated_by'] = $user_id;
        $data['created_by'] = $user_id;
        
        if (!empty($data['status'])) {
            $data['status'] = 1;
        }

        $wpdb->insert($table_name, $data);
        $insert_id = $wpdb->insert_id;
		//self::get_redis_zebpay();
        return $insert_id;
    }
	
	
	public static function nw_update_utility_image_segment($id, $data) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_image_segment';
          if($_FILES['upload']['name']) {
              if(!$_FILES['upload']['error']) {
                //validate the file
                $new_file_name = strtolower($_FILES['upload']['tmp_name']); 
                if($_FILES['upload']['size'] > (900000)) {
                           wp_die('Your file size is to large.');
                }
                else {          
                  require_once( ABSPATH . 'wp-admin/includes/image.php' );
                  require_once( ABSPATH . 'wp-admin/includes/file.php' );
                  require_once( ABSPATH . 'wp-admin/includes/media.php' );
                  $file_id = media_handle_upload( 'upload', 0 );
                 if($file_id){
                  $data['image'] = $file_id;
                 }
                }
              }
              else {               
                wp_die('Error: '.$_FILES['upload']['error']);
              }
            }else{
				unset($data['image']);
			}		
		if (!empty($data['status'])) {
			$data['status'] = 1;
		}
		$result = $wpdb->update($table_name, $data, array('ID' => $id));
		//self::get_redis_zebpay();
		return $result;
    }
	
	 public static function nw_get_single_image_segment($id) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_image_segment';

		$data = array();
		$query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $id);

		$db_data = $wpdb->get_results($query, ARRAY_A);
		$data = array();
		if (is_array($db_data) && count($db_data) > 0) {
			$data = $db_data[0];
			//$data['data'] = unserialize($data['data']);
		}
		return $data;
      
     }
  
  
  /* Image Segment */	
  
   /////////////////////*Image did_you_know *///////////////
  	 public static function nw_insert_did_you_know($data) {
		 global $wpdb;
        $table_name = $wpdb->prefix . 'nw_did_you_know';
		 if($_FILES['upload']['name']) {
              if(!$_FILES['upload']['error']) {          
                $new_file_name = strtolower($_FILES['upload']['tmp_name']);        
                if($_FILES['upload']['size'] > (900000)) {                 
                  wp_die('Your file size is to large.');
                }
                else {                  
                  require_once( ABSPATH . 'wp-admin/includes/image.php' );
                  require_once( ABSPATH . 'wp-admin/includes/file.php' );
                  require_once( ABSPATH . 'wp-admin/includes/media.php' );   
                  $file_id = media_handle_upload( 'upload', 0 );				
				 if($file_id){
                  $data['image'] = $file_id;
                 }
                }
              }
              else {
                //set that to be the returned message
                wp_die('Error: '.$_FILES['upload']['error']);
              }
            } 
		
        $user_id = get_current_user_id();
        $data['created_at'] = time();
        $data['updated_by'] = $user_id;
        $data['created_by'] = $user_id;
        
        if (!empty($data['status'])) {
            $data['status'] = 1;
        }

        $wpdb->insert($table_name, $data);
        $insert_id = $wpdb->insert_id;
		//self::get_redis_zebpay();
        return $insert_id;
    }
	
	
	public static function nw_update_utility_did_you_know($id, $data) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_did_you_know';
          if($_FILES['upload']['name']) {
              if(!$_FILES['upload']['error']) {
                //validate the file
                $new_file_name = strtolower($_FILES['upload']['tmp_name']); 
                if($_FILES['upload']['size'] > (900000)) {
                           wp_die('Your file size is to large.');
                }
                else {          
                  require_once( ABSPATH . 'wp-admin/includes/image.php' );
                  require_once( ABSPATH . 'wp-admin/includes/file.php' );
                  require_once( ABSPATH . 'wp-admin/includes/media.php' );
                  $file_id = media_handle_upload( 'upload', 0 );
                 if($file_id){
                  $data['image'] = $file_id;
                 }
                }
              }
              else {               
                wp_die('Error: '.$_FILES['upload']['error']);
              }
            }else{
				unset($data['image']);
			}		
		if (!empty($data['status'])) {
			$data['status'] = 1;
		}
		$result = $wpdb->update($table_name, $data, array('ID' => $id));
		//self::get_redis_zebpay();
		return $result;
    }
	
	 public static function nw_get_single_did_you_know($id) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_did_you_know';

		$data = array();
		$query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $id);

		$db_data = $wpdb->get_results($query, ARRAY_A);
		$data = array();
		if (is_array($db_data) && count($db_data) > 0) {
			$data = $db_data[0];
			//$data['data'] = unserialize($data['data']);
		}
		return $data;
      
     }
  
  
  /* Image did_you_know */
  
     /////////////////////*Fight against Harassment  *///////////////
  	 public static function nw_insert_fah($data) {
		 global $wpdb;
		 
        $table_name = $wpdb->prefix . 'nw_fah';
		 if($_FILES['upload']['name']) 
		 {
              if(!$_FILES['upload']['error']) {          
                $new_file_name = strtolower($_FILES['upload']['tmp_name']);        
                if($_FILES['upload']['size'] > (900000)) {                 
                  wp_die('Your file size is to large.');
                }
                else {                  
                  require_once( ABSPATH . 'wp-admin/includes/image.php' );
                  require_once( ABSPATH . 'wp-admin/includes/file.php' );
                  require_once( ABSPATH . 'wp-admin/includes/media.php' );   
                  $file_id = media_handle_upload( 'upload', 0 );				
				 if($file_id){
                  $data['image'] = $file_id;
                 }
                }
              }
              else {
                //set that to be the returned message
                wp_die('Error: '.$_FILES['upload']['error']);
              }
            } 
		//	print_r($data);
		
        $user_id = get_current_user_id();
        $data['created_at'] = time();
        $data['updated_by'] = $user_id;
        $data['created_by'] = $user_id;
        
        if (!empty($data['status'])) {
            $data['status'] = 1;
        }

        $wpdb->insert($table_name, $data);
        $insert_id = $wpdb->insert_id;
		//self::get_redis_zebpay();
        return $insert_id;
    }
	
	
	public static function nw_update_utility_fah($id, $data) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_fah';
          if($_FILES['upload']['name']) {
              if(!$_FILES['upload']['error']) {
                //validate the file
                $new_file_name = strtolower($_FILES['upload']['tmp_name']); 
                if($_FILES['upload']['size'] > (900000)) {
                           wp_die('Your file size is to large.');
                }
                else {          
                  require_once( ABSPATH . 'wp-admin/includes/image.php' );
                  require_once( ABSPATH . 'wp-admin/includes/file.php' );
                  require_once( ABSPATH . 'wp-admin/includes/media.php' );
                  $file_id = media_handle_upload( 'upload', 0 );
                 if($file_id){
                  $data['image'] = $file_id;
                 }
                }
              }
              else {               
                wp_die('Error: '.$_FILES['upload']['error']);
              }
            }else{
				unset($data['image']);
			}		
		if (!empty($data['status'])) {
			$data['status'] = 1;
		}
		$result = $wpdb->update($table_name, $data, array('ID' => $id));
		//self::get_redis_zebpay();
		return $result;
    }
	
	 public static function nw_get_single_fah($id) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_fah';

		$data = array();
		$query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $id);

		$db_data = $wpdb->get_results($query, ARRAY_A);
		$data = array();
		if (is_array($db_data) && count($db_data) > 0) {
			$data = $db_data[0];
			//$data['data'] = unserialize($data['data']);
		}
		return $data;
      
     }
  
  
  /* Fight against Harassment end  */
  
       /////////////////////*Campaign Ambassador   *///////////////
  	 public static function nw_insert_ca($data) {
		 global $wpdb;
		 
        $table_name = $wpdb->prefix . 'nw_ca';
		 if($_FILES['upload']['name']) 
		 {
              if(!$_FILES['upload']['error']) {          
                $new_file_name = strtolower($_FILES['upload']['tmp_name']);        
                if($_FILES['upload']['size'] > (900000)) {                 
                  wp_die('Your file size is to large.');
                }
                else {                  
                  require_once( ABSPATH . 'wp-admin/includes/image.php' );
                  require_once( ABSPATH . 'wp-admin/includes/file.php' );
                  require_once( ABSPATH . 'wp-admin/includes/media.php' );   
                  $file_id = media_handle_upload( 'upload', 0 );				
				 if($file_id){
                  $data['image'] = $file_id;
                 }
                }
              }
              else {
                //set that to be the returned message
                wp_die('Error: '.$_FILES['upload']['error']);
              }
            } 
		//	print_r($data);
		
        $user_id = get_current_user_id();
        $data['created_at'] = time();
        $data['updated_by'] = $user_id;
        $data['created_by'] = $user_id;
        
        if (!empty($data['status'])) {
            $data['status'] = 1;
        }

        $wpdb->insert($table_name, $data);
        $insert_id = $wpdb->insert_id;
		//self::get_redis_zebpay();
        return $insert_id;
    }
	
	
	public static function nw_update_utility_ca($id, $data) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_ca';
          if($_FILES['upload']['name']) {
              if(!$_FILES['upload']['error']) {
                //validate the file
                $new_file_name = strtolower($_FILES['upload']['tmp_name']); 
                if($_FILES['upload']['size'] > (900000)) {
                           wp_die('Your file size is to large.');
                }
                else {          
                  require_once( ABSPATH . 'wp-admin/includes/image.php' );
                  require_once( ABSPATH . 'wp-admin/includes/file.php' );
                  require_once( ABSPATH . 'wp-admin/includes/media.php' );
                  $file_id = media_handle_upload( 'upload', 0 );
                 if($file_id){
                  $data['image'] = $file_id;
                 }
                }
              }
              else {               
                wp_die('Error: '.$_FILES['upload']['error']);
              }
            }else{
				unset($data['image']);
			}		
		if (!empty($data['status'])) {
			$data['status'] = 1;
		}
		$result = $wpdb->update($table_name, $data, array('ID' => $id));
		//self::get_redis_zebpay();
		return $result;
    }
	
	 public static function nw_get_single_ca($id) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_ca';

		$data = array();
		$query = $wpdb->prepare("SELECT * FROM $table_name WHERE ID = %d", $id);

		$db_data = $wpdb->get_results($query, ARRAY_A);
		$data = array();
		if (is_array($db_data) && count($db_data) > 0) {
			$data = $db_data[0];
			//$data['data'] = unserialize($data['data']);
		}
		return $data;
      
     }
  
  
  /* Campaign Ambassador  end  */
}

$site_url = site_url();

register_activation_hook(__FILE__, array('Itsnotok_manage', 'create_tables'));
Itsnotok_manage::init_microsite();
 
?>