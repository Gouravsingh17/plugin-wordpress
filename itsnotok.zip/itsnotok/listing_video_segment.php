<?php

/**
 * Create a new table class that will extend the WP_List_Table
 */

class Nw_listing_itsnotokvs extends WP_List_Table {

    /**
     * Prepare the items for the table to process
     *
     * @return Void
     */
    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();
        $data = $this->table_data();

        if (empty($data))
            $data = array();
        $counts = array_count_values(array_flip(array_column($data, 'group')));
        usort($data, array(&$this, 'sort_data'));
        $perPage = 10;

        $currentPage = $this->get_pagenum();
        $totalItems = count($data);
        $this->set_pagination_args(array(
            'total_items' => $totalItems,
            'per_page' => $perPage
        ));
        $data = array_slice($data, (($currentPage - 1) * $perPage), $perPage);
        $this->_column_headers = array($columns, $hidden, $sortable);
        $this->items = $data;
    }

    /**
     * Override the parent columns method. Defines the columns to use in your listing table
     *
     * @return Array
     */
    public function get_columns() {
        $columns = array(
			'title'=>'title',				
			'videoid'=>'Video ID',				
			'status' => 'Status',
			'action' => 'Action',
		);
        return $columns;
    }

  
	function column_title($item) {
		return stripslashes($item['title']);
	}
	function column_videoid($item) {
		return stripslashes($item['videoId']);
	}
	
	function column_status($item) {
        $all_statuses = Itsnotok_manage::nw_get_all_status_panel();
        return $all_statuses[$item['status']];
    }

	function column_action($item) {
        $actions = array('edit' => sprintf('<a href="?page=' . Itsnotok_manage::$page_slug2 . '&action=new&id=%s">%s</a>', $item['ID'], __('Edit', 'pr_')),);

        return $actions['edit'];
    }


    public function get_hidden_columns() {
        return array();
    }

    /**
     * Define the sortable columns
     *
     * @return Array
     */
     public function get_sortable_columns() {
        $sortable_columns = array(
            'title' => array('title', true),
            'status' => array('status', true),
        );
        return $sortable_columns;
    } 

 


    /**
     * Get the table data
     *
     * @return Array
     */
    private function table_data() {  
		
		global $wpdb;
		$table_name = $wpdb->prefix . 'nw_itsnotok_video_segment';
		$listQuery =  "SELECT * FROM `$table_name` ORDER BY ID DESC";		
		$allData = $wpdb->get_results($listQuery, ARRAY_A);
		return $allData;  
    }

    public function column_default($item, $column_name) {
        switch ($column_name) {
            case 'title':
            case 'status':			
                return $item[$column_name];
            default:
                return print_r($item, true);
        }
    }

    /**
     * Allows you to sort the data by the variables set in the $_GET
     *
     * @return Mixed
     */
    private function sort_data($a, $b) {
        $orderby = 'display_order';
        $order = 'asc';
        if (!empty($_GET['orderby'])) {
            $orderby = $_GET['orderby'];
        }
        if (!empty($_GET['order'])) {
            $order = $_GET['order'];
        }
        $result = strnatcmp($a[$orderby], $b[$orderby]);
        if ($order === 'asc') {
            return $result;
        }
        return -$result;
    }

}

$nw18ListTable = new Nw_listing_itsnotokvs();
$nw18ListTable->prepare_items();



	
?>




<div class = "wrap">
<h2 >Video Segment&nbsp;
    <a class="add-new-h2" href="<?php echo get_admin_url(get_current_blog_id(), 'admin.php?page=' . Itsnotok_manage::$page_slug2 . '&action=new'); ?>"><?php _e('Add New ', 'pr') ?></a> 
</h2>

<form id="form" name="frmdata" method="post" > 

<input type="hidden" name="position_trv" id="input_hidden_position_trv" value=""/> 
<input type="hidden" name="action" value="simple_data_ordering_zebpay">

    <?php $nw18ListTable->display(); ?>
</form>

<style>
table.widefat tbody th, table.widefat tbody td { cursor: move; }

</style>
<script type="text/javascript">
      //jQuery('tbody').sortable();
	  
	  jQuery( "#the-list" ).sortable({
        delay: 150,
        stop: function() {
            var selectedData = new Array();
            jQuery('#the-list>tr').each(function() {
                selectedData.push(jQuery(this).attr("id"));
            });
			jQuery('#input_hidden_position_trv').val(JSON.stringify(selectedData)); //store array
			//jQuery('#positionbtn').show();
            updateOrder_trv(selectedData);
        }
    });


    function updateOrder_trv(data) {
		console.log(data);
        jQuery.ajax({
            url:ajaxurl,
            type:'post',
            data:{position_trv:data,action: 'simple_data_ordering_zebpay'},
            success:function($response){
				//console.log($response);
                alert('Change successfully saved');
            }
        })
    }
</script>
 



